Active Contributor :
1)	Sunil Mittal (BITS ID: 2021SC04968)
2)	Indira Saha (BITS ID: 2021sc04956)
3)	Vikram Panwar (BITS ID: 2021sc04958)
4)	Kirti Karki (BITS ID: 2021sc04967)


Instructions :

1) BITS Assignment 2 Word Document
	It contains the explanation and theory behind the algorithms and implementation of those algorithms in the current assignment. It also has code for both part a and part b.

2) BITS Assignment_MinMax_Game_implementation
 It contains the python script as well as step wise explanation, Kindly review the file carefully and execute only the complete code as some of the snippets are there for explanation of how that feature is implemented in main script.

3) ACIAssignment_Prolog
 It contains the prolog source file for the rules implementation of the decision tree , kindly  see the word document to see the output of the prolog program with trace enabled in Prolog Console.
